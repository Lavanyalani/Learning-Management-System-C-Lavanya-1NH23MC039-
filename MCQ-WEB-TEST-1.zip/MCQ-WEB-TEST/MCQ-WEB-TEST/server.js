const express = require('express');
const mysql = require('mysql2/promise');
const bodyParser = require('body-parser');
const path = require('path');
const app = express();

app.use(bodyParser.json());

// Serve static files from the 'public' directory
app.use(express.static(path.join(__dirname, 'public')));

// Create a connection pool to manage MySQL connections
const pool = mysql.createPool({
    host: 'localhost',
    port: 3306,
    user: 'root',
    password: 'root',
    database: 'mcq_test',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});

// Landing page route
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'landing.html'));
});

// Fetch a specific student by ID
app.get('/students/:id', async (req, res) => {
    const studentId = req.params.id;
    try {
        const connection = await pool.getConnection();
        const [students] = await connection.execute('SELECT * FROM students WHERE id = ?', [studentId]);
        connection.release();
        
        if (students.length > 0) {
            res.json(students[0]); // Return the first student found
        } else {
            res.status(404).send('Student not found');
        }
    } catch (err) {
        console.error('Error fetching student:', err);
        res.status(500).send('Error fetching student');
    }
});

// Submit results
app.post('/submit-results', async (req, res) => {
    const { studentId, results, score } = req.body;

    console.log('Received submission:', req.body); // Log the received submission

    const query = 'INSERT INTO results (student_id, results, score) VALUES (?, ?, ?)';
    try {
        const connection = await pool.getConnection();
        const [result] = await connection.execute(query, [studentId, JSON.stringify(results), score]);
        connection.release(); // Release the connection back to the pool
        console.log('Result save response:', result); // Log the response from the save operation
        res.send('Results saved successfully');
    } catch (err) {
        console.error('Error saving results:', err);
        res.status(500).send('Error saving results');
    }
});

// Fetch all results
app.get('/results', async (req, res) => {
    const query = `
        SELECT r.student_id, s.firstname, s.lastname, r.score
        FROM results r
        JOIN students s ON r.student_id = s.id
    `;
    try {
        const connection = await pool.getConnection();
        const [results] = await connection.execute(query);
        connection.release();
        res.send(results);
    } catch (err) {
        console.error('Error fetching results:', err);
        res.status(500).send('Error fetching results');
    }
});

// Create a new student
app.post('/students', async (req, res) => {
    const { firstname, lastname, email } = req.body;
    const query = 'INSERT INTO students (firstname, lastname, email) VALUES (?, ?, ?)';
    try {
        const connection = await pool.getConnection();
        const [result] = await connection.execute(query, [firstname, lastname, email]);
        connection.release();
        res.send('Student created successfully');
    } catch (err) {
        console.error('Error creating student:', err);
        res.status(500).send('Error creating student');
    }
});

// Fetch all students
app.get('/students', async (req, res) => {
    const query = 'SELECT * FROM students';
    try {
        const connection = await pool.getConnection();
        const [students] = await connection.execute(query);
        connection.release();
        res.send(students);
    } catch (err) {
        console.error('Error fetching students:', err);
        res.status(500).send('Error fetching students');
    }
});

// Serve results page
app.get('/results.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'results.html'));
});

// Clear results endpoint for admin
app.delete('/results', async (req, res) => {
    const query = 'DELETE FROM results';
    try {
        const connection = await pool.getConnection();
        await connection.execute(query);
        connection.release();
        console.log('All results cleared');
        res.send('All results cleared successfully');
    } catch (err) {
        console.error('Error clearing results:', err);
        res.status(500).send('Error clearing results');
    }
});

// Admin route to view results
app.get('/admin/results', async (req, res) => {
    const query = `
        SELECT r.student_id, s.firstname, s.lastname, r.score
        FROM results r
        JOIN students s ON r.student_id = s.id
    `;
    try {
        const connection = await pool.getConnection();
        const [results] = await connection.execute(query);
        connection.release();
        res.send(results);
    } catch (err) {
        console.error('Error fetching results:', err);
        res.status(500).send('Error fetching results');
    }
});

// Delete a single result by student ID
app.delete('/results/:id', async (req, res) => {
    const studentId = req.params.id;
    const query = 'DELETE FROM results WHERE student_id = ?';
    try {
        const connection = await pool.getConnection();
        const [result] = await connection.execute(query, [studentId]);
        connection.release();
        if (result.affectedRows > 0) {
            res.send('Result deleted successfully');
        } else {
            res.status(404).send('Result not found');
        }
    } catch (err) {
        console.error('Error deleting result:', err);
        res.status(500).send('Error deleting result');
    }
});

// Start the server
app.listen(3000, () => {
    console.log('Server is running on port 3000');
});
