const questions = [
    { text: "Which of the following is a valid Java variable declaration?", options: ["int 1a;", "int a;", "a int;", "integer a;"], correct: 1 },
    { text: "What is the default value of a boolean variable in Java?", options: ["true", "false", "null", "undefined"], correct: 1 },
    { text: "Which keyword is used to create a new object in Java?", options: ["create", "new", "object", "construct"], correct: 1 },
    { text: "Which of these is the correct syntax for a switch statement in Java?", options: ["switch (x) {}", "switch {x} {}", "switch (x): {}", "switch x {}"], correct: 0 },
    { text: "Which method is used to find the length of a string in Java?", options: ["length()", "size()", "getLength()", "length"], correct: 0 },
    { text: "Which of the following is used to handle exceptions in Java?", options: ["try-catch", "throw-catch", "do-while", "catch-except"], correct: 0 },
    { text: "What is the size of an int in Java?", options: ["16 bits", "32 bits", "64 bits", "128 bits"], correct: 1 },
    { text: "Which of the following is not a Java primitive type?", options: ["int", "boolean", "String", "char"], correct: 2 },
    { text: "Which of these is the correct syntax for an array declaration in Java?", options: ["int[] arr;", "int arr[];", "arr[] int;", "int arr;[]"], correct: 0 },
    { text: "Which method is used to start a thread in Java?", options: ["start()", "run()", "begin()", "execute()"], correct: 0 },
    { text: "What is the result of the following expression in Java: 10 / 3?", options: ["3", "3.33", "4", "Error"], correct: 0 },
    { text: "Which of these is the correct way to declare a constant in Java?", options: ["final int x;", "int final x;", "const int x;", "constant int x;"], correct: 0 },
    { text: "Which collection class is used to store elements in a map in Java?", options: ["ArrayList", "HashMap", "TreeSet", "HashSet"], correct: 1 },
    { text: "Which access modifier makes a method visible only within its class in Java?", options: ["private", "protected", "public", "default"], correct: 0 },
    { text: "Which of the following is true about Java?", options: ["Java is platform-dependent", "Java is platform-independent", "Java is a scripting language", "Java is a web language"], correct: 1 }
];

const optionLabels = ["A", "B", "C", "D"];
let currentQuestionIndex = 0;
let selectedOptions = [];
let selectedStudentId = null;
let timerInterval;

const studentSelection = document.getElementById('student-selection');
const studentIdInput = document.getElementById('student-id');
const startTestButton = document.getElementById('start-test-button');
const quizContainer = document.getElementById('quiz-container');
const questionText = document.getElementById('question-text');
const optionsList = document.getElementById('options');
const nextButton = document.getElementById('next-button');
const submitButton = document.getElementById('submit-button');
const resultContainer = document.getElementById('result');
const scoreElement = document.getElementById('score');
const answersContainer = document.getElementById('answers-container');
const timerElement = document.getElementById('timer');

// Function to validate Student ID and start quiz
async function validateStudentAndStartQuiz() {
    selectedStudentId = studentIdInput.value;
    if (!selectedStudentId) {
        alert("Please enter a valid Student ID.");
        return;
    }

    // Start quiz and timer
    startTimer(10); // 10 minutes timer
    studentSelection.classList.add('hidden');
    quizContainer.classList.remove('hidden');
    loadQuestion();
}

startTestButton.addEventListener('click', validateStudentAndStartQuiz);

function loadQuestion() {
    const question = questions[currentQuestionIndex];
    questionText.textContent = question.text;
    optionsList.innerHTML = '';
    question.options.forEach((option, index) => {
        const li = document.createElement('li');
        const label = document.createElement('label');
        label.innerHTML = `${optionLabels[index]} <input type="radio" name="option" value="${index}"> ${option}`;
        li.appendChild(label);
        optionsList.appendChild(li);
    });
}

nextButton.addEventListener('click', () => {
    const selectedOption = document.querySelector('input[name="option"]:checked');
    if (selectedOption) {
        selectedOptions[currentQuestionIndex] = parseInt(selectedOption.value);
    }
    currentQuestionIndex++;
    if (currentQuestionIndex < questions.length) {
        loadQuestion();
    } else {
        nextButton.style.display = 'none';
        submitButton.style.display = 'inline-block';
    }
});

submitButton.addEventListener('click', submitQuiz);

function submitQuiz() {
    clearInterval(timerInterval); // Stop the timer
    let score = 0;
    selectedOptions.forEach((option, index) => {
        if (option === questions[index].correct) {
            score++;
        }
    });

    scoreElement.textContent = `${score} / ${questions.length}`;
    resultContainer.classList.remove('hidden');
    quizContainer.classList.add('hidden');
}

function startTimer(minutes) {
    let time = minutes * 60;
    timerInterval = setInterval(() => {
        const mins = Math.floor(time / 60);
        const secs = time % 60;
        timerElement.textContent = `${mins}:${secs < 10 ? '0' + secs : secs}`;
        time--;

        if (time < 0) {
            clearInterval(timerInterval);
            alert("Time's up! Submitting the quiz.");
            submitQuiz();
        }
    }, 1000);
}

document.getElementById('show-answers-button').addEventListener('click', () => {
    answersContainer.innerHTML = ''; // Clear previous answers
    questions.forEach((question, index) => {
        const userAnswer = selectedOptions[index];
        const correctAnswer = question.correct;
        
        // Create a div container for each question's answers
        const questionDiv = document.createElement('div');
        questionDiv.classList.add('question-container');
        questionDiv.innerHTML = `<p><strong>Q${index + 1}: ${question.text}</strong></p>`;
        
        // Create a div for each option's label and answer status
        question.options.forEach((option, optionIndex) => {
            const optionElement = document.createElement('p');
            optionElement.textContent = `${optionLabels[optionIndex]}. ${option}`;
            if (optionIndex === correctAnswer) {
                optionElement.classList.add('correct');
            } else if (userAnswer === optionIndex) {
                optionElement.classList.add('incorrect');
            }
            questionDiv.appendChild(optionElement);
        });

        // Append the question div to the answers container
        answersContainer.appendChild(questionDiv);
    });

    // Display the answers section
    answersContainer.classList.remove('hidden');
});
