// Sample question data (reduced to 10 questions)
const questions = [
    { text: "What is the time complexity of the best case of Merge Sort?", options: ["O(n)", "O(n log n)", "O(n^2)", "O(log n)"], correct: 1 },
    { text: "Which of the following algorithms is used to solve the knapsack problem?", options: ["Merge Sort", "Dijkstra's Algorithm", "Dynamic Programming", "Quick Sort"], correct: 2 },
    { text: "Which sorting algorithm has the best worst-case time complexity?", options: ["Bubble Sort", "Merge Sort", "Insertion Sort", "Selection Sort"], correct: 1 },
    { text: "What is the space complexity of Quick Sort?", options: ["O(1)", "O(log n)", "O(n)", "O(n^2)"], correct: 1 },
    { text: "What is the principle behind the Divide and Conquer algorithm?", options: ["Solving the problem by breaking it into subproblems", "Sorting the input", "Greedy approach", "Brute force solution"], correct: 0 },
    { text: "Which of the following is not a greedy algorithm?", options: ["Huffman Coding", "Dijkstra’s Algorithm", "Prim’s Algorithm", "Merge Sort"], correct: 3 },
    { text: "In which scenario would a Binary Search be most effective?", options: ["Unsorted array", "Sorted array", "Linked list", "Hash table"], correct: 1 },
    { text: "What is the time complexity of accessing an element in an array?", options: ["O(1)", "O(n)", "O(log n)", "O(n^2)"], correct: 0 },
    { text: "What is the time complexity of finding the shortest path in a graph using Dijkstra's algorithm?", options: ["O(n)", "O(n log n)", "O(n^2)", "O(n^3)"], correct: 1 },
    { text: "Which algorithm is used to find the minimum spanning tree of a graph?", options: ["Dijkstra’s Algorithm", "Prim’s Algorithm", "Depth First Search", "Breadth First Search"], correct: 1 }
];

const optionLabels = ["A", "B", "C", "D"];
let currentQuestionIndex = 0;
let selectedOptions = [];
let selectedStudentId = null;
let timer;
let timeLeft = 600; // 10 minutes in seconds

const studentSelection = document.getElementById('student-selection');
const studentIdInput = document.getElementById('student-id');
const startTestButton = document.getElementById('start-test-button');
const quizContainer = document.getElementById('quiz-container');
const questionText = document.getElementById('question-text');
const optionsList = document.getElementById('options');
const nextButton = document.getElementById('next-button');
const submitButton = document.getElementById('submit-button');
const resultContainer = document.getElementById('result');
const scoreElement = document.getElementById('score');
const showAnswersButton = document.getElementById('show-answers-button');
const answersContainer = document.getElementById('answers-container');
const answersList = document.getElementById('answers-list');
const timerElement = document.getElementById('timer');

// Function to validate Student ID and start quiz
async function validateStudentAndStartQuiz() {
    selectedStudentId = studentIdInput.value;
    if (!selectedStudentId) {
        alert("Please enter a valid Student ID.");
        return;
    }

    try {
        const response = await fetch(`/students/${selectedStudentId}`);
        if (!response.ok) {
            alert("Invalid Student ID. Please try again.");
            return;
        }
        const student = await response.json();
        console.log(`Student validated: ${student.firstname} ${student.lastname}`);

        // Show the quiz container and load the first question
        studentSelection.classList.add('hidden');
        quizContainer.classList.remove('hidden');
        loadQuestion();
        startTimer();
    } catch (error) {
        console.error('Error validating student:', error);
        alert("Error occurred while validating the student. Please try again.");
    }
}

// Listen for Enter key press on student ID input field
studentIdInput.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') {
        validateStudentAndStartQuiz();
    }
});

// Start test on button click
startTestButton.addEventListener('click', validateStudentAndStartQuiz);

// Load question and options into the DOM
function loadQuestion() {
    const question = questions[currentQuestionIndex];
    questionText.textContent = question.text;
    optionsList.innerHTML = ''; // Clear previous options
    question.options.forEach((option, index) => {
        const li = document.createElement('li');
        const label = document.createElement('label');
        label.innerHTML = `${optionLabels[index]} <input type="radio" name="option" value="${index}"> ${option}`;
        li.appendChild(label);
        optionsList.appendChild(li);
    });

    // Show next button
    nextButton.style.display = 'inline-block';
    submitButton.style.display = 'none'; // Hide submit button initially
    answersContainer.classList.add('hidden');
}

// Handle next button click
nextButton.addEventListener('click', () => {
    const selectedOption = document.querySelector('input[name="option"]:checked');
    if (selectedOption) {
        selectedOptions[currentQuestionIndex] = parseInt(selectedOption.value);
    }
    currentQuestionIndex++;
    
    if (currentQuestionIndex === questions.length - 1) {
        // Show submit button on last question
        nextButton.style.display = 'none';
        submitButton.style.display = 'inline-block';
    } else {
        loadQuestion();
    }
});

// Handle submit button click
submitButton.addEventListener('click', () => {
    const selectedOption = document.querySelector('input[name="option"]:checked');
    if (selectedOption) {
        selectedOptions[currentQuestionIndex] = parseInt(selectedOption.value);
    }

    // Calculate score
    const score = selectedOptions.filter((selected, index) => selected === questions[index].correct).length;
    scoreElement.textContent = `${score} / ${questions.length}`;

    // Show result and answers button
    quizContainer.classList.add('hidden');
    resultContainer.classList.remove('hidden');
    answersContainer.classList.remove('hidden');
    showAnswersButton.style.display = 'inline-block';
});

// Show answers when clicked
showAnswersButton.addEventListener('click', () => {
    let answerText = '<h3>Correct Answers:</h3>';
    answersList.innerHTML = ''; // Clear previous answers

    questions.forEach((question, index) => {
        const questionDiv = document.createElement('div');
        questionDiv.classList.add('question-container');

        let questionHTML = `<strong>${question.text}</strong><br>`;
        question.options.forEach((option, optionIndex) => {
            const optionClass = (selectedOptions[index] === optionIndex && selectedOptions[index] !== question.correct) ? 'incorrect' :
                                (optionIndex === question.correct) ? 'correct' : '';
            questionHTML += `<span class="option ${optionClass}">${optionLabels[optionIndex]}. ${option}</span><br>`;
        });

        questionDiv.innerHTML = questionHTML;
        answersList.appendChild(questionDiv);
    });
});

// Start the timer countdown
function startTimer() {
    timer = setInterval(() => {
        const minutes = Math.floor(timeLeft / 60);
        const seconds = timeLeft % 60;
        timerElement.textContent = `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
        timeLeft--;

        if (timeLeft < 0) {
            clearInterval(timer);
            submitQuiz();
        }
    }, 1000);
}

// Submit quiz automatically when time is up
function submitQuiz() {
    const selectedOption = document.querySelector('input[name="option"]:checked');
    if (selectedOption) {
        selectedOptions[currentQuestionIndex] = parseInt(selectedOption.value);
    }

    // Calculate score
    const score = selectedOptions.filter((selected, index) => selected === questions[index].correct).length;
    scoreElement.textContent = `${score} / ${questions.length}`;

    // Show result and answers button
    quizContainer.classList.add('hidden');
    resultContainer.classList.remove('hidden');
    answersContainer.classList.remove('hidden');
    showAnswersButton.style.display = 'inline-block';
}
