const questions = [
    { text: "Which of the following is a correct syntax for declaring a C++ variable?", options: ["int x = 10;", "integer x = 10;", "x = 10;", "int: x = 10;"], correct: 0 },
    { text: "What is the correct way to declare a constant in C++?", options: ["const int x = 5;", "constant int x = 5;", "x = const 5;", "const x = 5;"], correct: 0 },
    { text: "Which of the following is used to allocate memory dynamically in C++?", options: ["new", "malloc", "calloc", "realloc"], correct: 0 },
    { text: "What does the 'public' access modifier mean in C++?", options: ["The member can be accessed from anywhere", "The member can only be accessed inside the class", "The member can only be accessed by subclasses", "The member is private"], correct: 0 },
    { text: "Which of the following is the correct syntax to declare a pointer in C++?", options: ["int *p;", "pointer int p;", "int p*;", "int p*"], correct: 0 },
    { text: "Which of the following is used to terminate the loop in C++?", options: ["break", "stop", "exit", "terminate"], correct: 0 },
    { text: "What is the default value of an uninitialized local variable in C++?", options: ["Undefined", "0", "NULL", "Depends on the type"], correct: 0 },
    { text: "Which of the following is a valid C++ data type?", options: ["int", "integer", "real", "boolean"], correct: 0 },
    { text: "Which keyword is used to inherit a class in C++?", options: ["extends", "inherits", "public", "class"], correct: 2 },
    { text: "Which of the following is the correct syntax for a C++ for loop?", options: ["for (int i = 0; i < 10; i++) {}", "for (int i = 0, i < 10; i++) {}", "for i = 0; i < 10; i++ {}", "for (i = 0; i < 10; i++) {}"], correct: 0 }
];

const optionLabels = ["A", "B", "C", "D"];
let currentQuestionIndex = 0;
let selectedOptions = [];
let selectedStudentId = null;

const studentSelection = document.getElementById('student-selection');
const studentIdInput = document.getElementById('student-id');
const startTestButton = document.getElementById('start-test-button');
const quizContainer = document.getElementById('quiz-container');
const questionText = document.getElementById('question-text');
const optionsList = document.getElementById('options');
const nextButton = document.getElementById('next-button');
const submitButton = document.getElementById('submit-button');
const resultContainer = document.getElementById('result');
const scoreElement = document.getElementById('score');
const timerElement = document.getElementById('timer');
const answersContainer = document.getElementById('answers-container');
const answersList = document.getElementById('answers-list');
const showAnswersButton = document.getElementById('show-answers-button');
let timerInterval;

// Start the timer
function startTimer(durationInMinutes) {
    let timeRemaining = durationInMinutes * 60;
    timerInterval = setInterval(() => {
        const minutes = Math.floor(timeRemaining / 60);
        const seconds = timeRemaining % 60;
        timerElement.textContent = `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
        timeRemaining--;

        if (timeRemaining < 0) {
            clearInterval(timerInterval);
            alert("Time's up! Submitting your answers...");
            submitButton.click();
        }
    }, 1000);
}

// Validate Student ID and start quiz
async function validateStudentAndStartQuiz() {
    selectedStudentId = studentIdInput.value;
    if (!selectedStudentId) {
        alert("Please enter a valid Student ID.");
        return;
    }

    studentSelection.classList.add('hidden');
    quizContainer.classList.remove('hidden');
    startTimer(10); // 10-minute timer
    loadQuestion();
}

// Listen for Enter key
studentIdInput.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') {
        validateStudentAndStartQuiz();
    }
});

startTestButton.addEventListener('click', validateStudentAndStartQuiz);

// Load a question
function loadQuestion() {
    const question = questions[currentQuestionIndex];
    questionText.textContent = question.text;
    optionsList.innerHTML = '';
    question.options.forEach((option, index) => {
        const li = document.createElement('li');
        const label = document.createElement('label');
        label.innerHTML = `${optionLabels[index]} <input type="radio" name="option" value="${index}"> ${option}`;
        li.appendChild(label);
        optionsList.appendChild(li);
    });
    nextButton.style.display = 'inline-block';
    submitButton.style.display = currentQuestionIndex === questions.length - 1 ? 'inline-block' : 'none';
}

// Handle "Next" button
nextButton.addEventListener('click', () => {
    const selectedOption = document.querySelector('input[name="option"]:checked');
    if (selectedOption) {
        selectedOptions[currentQuestionIndex] = parseInt(selectedOption.value);
    }
    currentQuestionIndex++;
    if (currentQuestionIndex < questions.length) {
        loadQuestion();
    }
});

// Handle "Submit" button
submitButton.addEventListener('click', () => {
    let score = 0;
    selectedOptions.forEach((option, index) => {
        if (option === questions[index].correct) {
            score++;
        }
    });

    scoreElement.textContent = `${score} / ${questions.length}`;
    resultContainer.classList.remove('hidden');
    quizContainer.classList.add('hidden');
    clearInterval(timerInterval);
});

// Show correct answers
showAnswersButton.addEventListener('click', () => {
    answersList.innerHTML = '';
    questions.forEach((question, index) => {
        const questionDiv = document.createElement('div');
        questionDiv.classList.add('question-container');

        const questionText = document.createElement('p');
        questionText.textContent = `${index + 1}. ${question.text}`;

        const optionsList = document.createElement('ul');
        question.options.forEach((option, i) => {
            const optionLi = document.createElement('li');
            const optionLabel = document.createElement('span');
            optionLabel.textContent = `${optionLabels[i]}: ${option}`;

            if (selectedOptions[index] === i) {
                optionLabel.classList.add(selectedOptions[index] === question.correct ? 'correct' : 'incorrect');
            } else if (i === question.correct) {
                optionLabel.classList.add('correct');
            }

            optionLi.appendChild(optionLabel);
            optionsList.appendChild(optionLi);
        });

        questionDiv.appendChild(questionText);
        questionDiv.appendChild(optionsList);
        answersList.appendChild(questionDiv);
    });

    resultContainer.classList.add('hidden');
    answersContainer.classList.remove('hidden');
});
