const questions = [
    { text: "What is Cloud Computing?", options: ["On-demand access to computing resources", "A type of web server", "A local network", "None of the above"], correct: 0 },
    { text: "Which service is NOT part of Cloud Computing?", options: ["IaaS", "PaaS", "SaaS", "LAN"], correct: 3 },
    { text: "Which cloud model allows users to manage and control the infrastructure?", options: ["Private Cloud", "Public Cloud", "Hybrid Cloud", "Community Cloud"], correct: 0 },
    { text: "What is the main benefit of Cloud Computing?", options: ["Cost Efficiency", "Slower data retrieval", "High energy consumption", "All of the above"], correct: 0 },
    { text: "Which of the following is an example of IaaS?", options: ["Google App Engine", "Amazon EC2", "Salesforce", "Dropbox"], correct: 1 },
    { text: "What does the acronym SaaS stand for?", options: ["Software as a Service", "System as a Service", "Software as a Storage", "None of the above"], correct: 0 },
    { text: "Which cloud service model offers the most flexibility?", options: ["IaaS", "PaaS", "SaaS", "FaaS"], correct: 0 },
    { text: "What is the primary characteristic of a Hybrid Cloud?", options: ["Mix of public and private clouds", "Only private resources", "Fully managed resources", "None of the above"], correct: 0 },
    { text: "What is the primary function of a Virtual Machine in the cloud?", options: ["Storage management", "Processing data", "Network routing", "Emulating hardware resources"], correct: 3 },
    { text: "Which cloud model is most suitable for government data storage?", options: ["Private Cloud", "Public Cloud", "Hybrid Cloud", "None of the above"], correct: 0 }
];

const optionLabels = ["A", "B", "C", "D"];
let currentQuestionIndex = 0;
let selectedOptions = [];
let selectedStudentId = null;

const studentSelection = document.getElementById('student-selection');
const studentIdInput = document.getElementById('student-id');
const startTestButton = document.getElementById('start-test-button');
const quizContainer = document.getElementById('quiz-container');
const questionText = document.getElementById('question-text');
const optionsList = document.getElementById('options');
const nextButton = document.getElementById('next-button');
const submitButton = document.getElementById('submit-button');
const resultContainer = document.getElementById('result');
const scoreElement = document.getElementById('score');
const answersContainer = document.getElementById('answers-container');
const answersList = document.getElementById('answers-list');
const showAnswersButton = document.getElementById('show-answers-button');

// Timer variables
let timerInterval;
let timeLeft = 600; // 10 minutes in seconds

const timerDisplay = document.getElementById('timer');

function startTimer() {
    timerInterval = setInterval(function () {
        const minutes = Math.floor(timeLeft / 60);
        const seconds = timeLeft % 60;
        timerDisplay.textContent = `${minutes < 10 ? '0' : ''}${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
        if (timeLeft <= 0) {
            clearInterval(timerInterval);
            submitQuiz();
        } else {
            timeLeft--;
        }
    }, 1000);
}

function stopTimer() {
    clearInterval(timerInterval);
}

async function submitQuiz() {
    let score = 0;
    selectedOptions.forEach((option, index) => {
        if (option === questions[index].correct) {
            score++;
        }
    });

    scoreElement.textContent = `${score} / ${questions.length}`;
    resultContainer.classList.remove('hidden');
    quizContainer.classList.add('hidden');
    stopTimer();
}

function loadQuestion() {
    const question = questions[currentQuestionIndex];
    questionText.textContent = question.text;
    optionsList.innerHTML = '';
    question.options.forEach((option, index) => {
        const li = document.createElement('li');
        const label = document.createElement('label');
        label.innerHTML = `${optionLabels[index]} <input type="radio" name="option" value="${index}"> ${option}`;
        li.appendChild(label);
        optionsList.appendChild(li);
    });
}

function validateStudentAndStartQuiz() {
    selectedStudentId = studentIdInput.value;
    if (!selectedStudentId) {
        alert("Please enter a valid Student ID.");
        return;
    }

    studentSelection.classList.add('hidden');
    quizContainer.classList.remove('hidden');
    loadQuestion();
    startTimer();
}

startTestButton.addEventListener('click', validateStudentAndStartQuiz);

nextButton.addEventListener('click', () => {
    const selectedOption = document.querySelector('input[name="option"]:checked');
    if (selectedOption) {
        selectedOptions[currentQuestionIndex] = parseInt(selectedOption.value);
    }
    currentQuestionIndex++;
    if (currentQuestionIndex < questions.length) {
        loadQuestion();
    } else {
        nextButton.style.display = 'none';
        submitButton.style.display = 'inline-block';
    }
});

submitButton.addEventListener('click', submitQuiz);

// Show Answers Feature
showAnswersButton.addEventListener('click', () => {
    answersList.innerHTML = '';
    questions.forEach((question, index) => {
        const questionDiv = document.createElement('div');
        questionDiv.className = 'answer-container';

        const questionText = document.createElement('p');
        questionText.textContent = `${index + 1}. ${question.text}`;
        questionDiv.appendChild(questionText);

        question.options.forEach((option, optionIndex) => {
            const optionText = document.createElement('p');
            optionText.textContent = `${optionLabels[optionIndex]}. ${option}`;
            if (optionIndex === question.correct) {
                optionText.style.color = 'green'; // Correct answer in green
            }
            if (selectedOptions[index] === optionIndex && optionIndex !== question.correct) {
                optionText.style.color = 'red'; // Incorrect answer in red
            }
            questionDiv.appendChild(optionText);
        });

        answersList.appendChild(questionDiv);
    });

    resultContainer.classList.add('hidden');
    answersContainer.classList.remove('hidden');
});
