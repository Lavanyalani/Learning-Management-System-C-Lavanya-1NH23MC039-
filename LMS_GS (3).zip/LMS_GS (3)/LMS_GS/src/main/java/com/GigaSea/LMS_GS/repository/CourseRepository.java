package com.GigaSea.LMS_GS.repository;

import com.GigaSea.LMS_GS.model.Course;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CourseRepository extends JpaRepository<Course, Long> {
}
