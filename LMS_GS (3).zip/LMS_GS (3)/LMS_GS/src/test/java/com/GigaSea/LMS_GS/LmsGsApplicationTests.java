package com.GigaSea.LMS_GS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LmsGsApplicationTests {

	@Test
	void contextLoads() {
	}

}
